public class Square {
    public void pay1(double amount) {
        System.out.println("Payment by Square : "+amount);
    }
    
}