public class RazorPayAdapter implements PaymentProcessor {
    private RazorPay razor;

    public RazorPayAdapter(RazorPay razor) {
        this.razor = razor;
    }
    public void processPayment(double amount) {
        razor.pay2(amount);
    }
}

