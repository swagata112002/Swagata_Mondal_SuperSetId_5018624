public class AdapterTest {
    public static void main(String[] args) {

        RazorPay razor = new RazorPay();
        PaymentProcessor ob1 = new RazorPayAdapter(razor);
        ob1.processPayment(100);

        Square square = new Square();
        PaymentProcessor ob2 = new SquareAdapter(square);
        ob2.processPayment(500);
    }
}



