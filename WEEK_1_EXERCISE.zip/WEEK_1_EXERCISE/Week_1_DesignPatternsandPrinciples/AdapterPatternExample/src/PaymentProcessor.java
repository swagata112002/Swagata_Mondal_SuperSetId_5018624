public interface PaymentProcessor {
    public void processPayment(double payAmount);
}
