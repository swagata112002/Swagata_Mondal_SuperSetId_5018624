public class RazorPay {
    public void pay2(double amount) {
        System.out.println("Payment by Razor Pay : "+amount);
    }
    
}

