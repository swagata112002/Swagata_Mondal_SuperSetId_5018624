public class Computer {
    String CPU;
    String RAM;
    String Storage;
    public static class Builder {
        String CPU;
        String RAM;
        String Storage;
        public Builder getCPU(String CPU) {
            this.CPU = CPU;
            return this;
        }

        public Builder getRAM(String RAM) {
            this.RAM = RAM;
            return this;
        }

        public Builder getStorage(String Storage) {
            this.Storage = Storage;
            return this;
        }
        public Computer build() {
            Computer obj = new Computer();
            obj.CPU = this.CPU;
            obj.RAM = this.RAM;
            obj.Storage = this.Storage;
            return obj;
        }
    }
    public String toString() {
        return ("Computer has the CPU:" + CPU + ", RAM:" + RAM + ", Storage:" + Storage);
    }
}
