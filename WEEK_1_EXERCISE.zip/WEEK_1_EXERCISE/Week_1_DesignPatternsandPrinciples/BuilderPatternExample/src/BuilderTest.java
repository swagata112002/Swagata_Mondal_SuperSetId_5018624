public class BuilderTest {
    public static void main(String[] args) {
        Computer comp = new Computer.Builder()
            .getCPU("Intel i5")
            .getRAM("12 GB")
            .getStorage("1TB Harddrive 256 GB SSD")
            .build();

        System.out.println(comp);
    }
}
