public class Test {
    public static void main(String[] args) {
        Logger ob = Logger.getIns();
        Logger ob1 = Logger.getIns();

        if (ob == ob1) {
            System.out.println("Both are in same instance.");
        } else {
            System.out.println("Both are in different instances.");
        }
    }
}

