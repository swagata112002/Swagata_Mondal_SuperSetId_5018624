public interface Command {
    void imple();
}