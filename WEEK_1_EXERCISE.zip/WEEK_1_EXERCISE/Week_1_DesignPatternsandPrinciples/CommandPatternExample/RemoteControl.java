public class RemoteControl {
    Command com;

    public void ccommand(Command com) {
        this.com = com;
    }

    public void pressButton() {
        com.imple();
    }
}
