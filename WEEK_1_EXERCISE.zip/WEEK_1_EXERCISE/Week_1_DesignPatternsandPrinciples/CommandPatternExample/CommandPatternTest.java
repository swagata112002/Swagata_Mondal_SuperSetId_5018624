public class CommandPatternTest {
    public static void main(String[] args) {
        Light l = new Light();
        Command lightOn = new LightOnCommand(l);
        Command lightOff = new LightOffCommand(l);
        RemoteControl remote = new RemoteControl();
        remote.ccommand(lightOn);
        remote.pressButton();
        remote.ccommand(lightOff);
        remote.pressButton();
    }
}
