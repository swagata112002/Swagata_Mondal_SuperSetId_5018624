public class LightOffCommand implements Command {
    Light l;

    public LightOffCommand(Light l) {
        this.l = l;
    }
    public void imple() {
        l.turnOff();
    }
}

