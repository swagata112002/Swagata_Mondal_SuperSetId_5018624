// CAN NOT ABLE TO DO THIS PROBLEM

public interface Stock {
    void register(Observer ob);
    void deregister(Observer ob);
    void notify();
}
