// CAN NOT ABLE TO DO THIS PROBLEM
public interface Observer {
    void update(double price);
}