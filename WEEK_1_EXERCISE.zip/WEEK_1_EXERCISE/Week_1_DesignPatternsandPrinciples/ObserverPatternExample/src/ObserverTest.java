// CAN NOT ABLE TO DO THIS PROBLEM
public class ObserverTest {
    
}
