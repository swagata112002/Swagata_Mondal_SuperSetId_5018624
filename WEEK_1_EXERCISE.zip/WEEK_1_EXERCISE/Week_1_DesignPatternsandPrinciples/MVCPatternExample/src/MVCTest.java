public class MVCTest {
    public static void main(String[] args) {

        Student student = new Student("Swagata Mondal", 48, "O");
        StudentView view = new StudentView();
        StudentController ob = new StudentController(student, view);
        ob.updateView();
        ob.setStudentName("Jaya Mondal");
        ob.setStudentGrade("E");
        ob.updateView();
    }
}

