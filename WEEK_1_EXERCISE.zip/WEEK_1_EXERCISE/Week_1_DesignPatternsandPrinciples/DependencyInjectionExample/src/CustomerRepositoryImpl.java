import java.util.*;
public class CustomerRepositoryImpl implements CustomerRepository {
    private Map<Integer, Customer> customer = new HashMap<>();
    public CustomerRepositoryImpl() {
        customer.put(1, new Customer(1, "Swagata Mondal"));
        customer.put(2, new Customer(2, "Kamal MOndal"));
        customer.put(3, new Customer(3, "Jaya MOndal"));
    }
    public Customer findCustomerById(int id) {
        return customer.get(id);
    }
}
