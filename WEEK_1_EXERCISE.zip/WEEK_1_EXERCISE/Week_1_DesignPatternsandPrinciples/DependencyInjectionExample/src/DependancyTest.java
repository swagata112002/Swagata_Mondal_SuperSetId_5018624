public class DependancyTest {
    public static void main(String[] args) {
        CustomerRepository customerrepository = new CustomerRepositoryImpl();
        CustomerService customerService = new CustomerService(customerrepository);
        Customer customer = customerService.getCustomerById(2);
        System.out.println(customer);
        Customer customer1 = customerService.getCustomerById(1);
        System.out.println(customer1);
    }
}
