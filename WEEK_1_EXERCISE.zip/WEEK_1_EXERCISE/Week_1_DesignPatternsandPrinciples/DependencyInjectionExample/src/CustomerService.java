public class CustomerService {
    private CustomerRepository customerrepository;
    public CustomerService(CustomerRepository customerrepository) {
        this.customerrepository = customerrepository;
    }

    public Customer getCustomerById(int id) {
        return customerrepository.findCustomerById(id);
    }
}
