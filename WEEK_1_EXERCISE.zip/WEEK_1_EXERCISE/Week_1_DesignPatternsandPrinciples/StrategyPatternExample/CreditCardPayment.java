public class CreditCardPayment implements PaymentStrategy {
    String number;
    String holder;
    String expiry;
    int cvv;
    public CreditCardPayment(String number, String holder, String expiry, int cvv) {
        this.number = number;
        this.holder = holder;
        this.cvv = cvv;
        this.expiry = expiry;
    }
    public void pay(double amount) {
        System.out.println("By Credit card paid "+amount);
    }
}