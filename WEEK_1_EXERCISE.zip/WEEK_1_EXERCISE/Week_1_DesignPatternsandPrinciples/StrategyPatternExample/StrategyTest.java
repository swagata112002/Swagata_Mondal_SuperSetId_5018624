public class StrategyTest {
    public static void main(String[] args) {
        PaymentContext obj = new PaymentContext();
        obj.setPaymentStrategy(new CreditCardPayment("11234567890", "Swagata Mondal", "12/12",4321));
        obj.pay(3500);
        obj.setPaymentStrategy(new PayPalPayment("admin@abc123"));
        obj.pay(8705);
    }
}
