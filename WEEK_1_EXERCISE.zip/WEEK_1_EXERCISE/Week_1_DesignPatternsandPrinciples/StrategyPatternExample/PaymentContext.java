public class PaymentContext {
    private PaymentStrategy ob;

    public void setPaymentStrategy(PaymentStrategy ob) {
        this.ob = ob;
    }

    public void pay(double amount) {
        if (ob != null) {
            ob.pay(amount);
        } else {
            System.out.println("Select a payment method:");
        }
    }
}
