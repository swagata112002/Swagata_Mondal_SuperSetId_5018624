public class PayPalPayment implements PaymentStrategy {
    String password;
    public PayPalPayment(String password) {
        this.password = password;
    }
    public void pay(double amount) {
        System.out.println("By Pay Pal paid "+amount);
    }
}
