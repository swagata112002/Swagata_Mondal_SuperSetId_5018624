public class ExcelDocument extends Document {
    public void write(){
        System.out.println("Writing EXCEL");
    }
    public void open() {
        System.out.println("Opening EXCEL");
    }
    public void close() {
        System.out.println("Closing EXCEL");
    }
}
