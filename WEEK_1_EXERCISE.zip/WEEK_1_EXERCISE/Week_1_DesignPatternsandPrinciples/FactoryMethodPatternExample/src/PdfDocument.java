public class PdfDocument extends Document{
    public void write(){
        System.out.println("Writing PDF");
    }
    public void open() {
        System.out.println("Opening PDF");
    }
    public void close() {
        System.out.println("Closing PDF");
    }
}
