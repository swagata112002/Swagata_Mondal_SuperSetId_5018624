public class FactTest {
    public static void main(String[] args) {
        System.out.println("Printing for word document");
        DocumentFactory ob = new WordFactory();
        Document word = ob.createDocument();
        word.write();
        word.open();
        word.close();

        System.out.println("Printing for pdf document");
        DocumentFactory ob1 = new PdfFactory();
        Document pdf = ob1.createDocument();
        pdf.write();
        pdf.open();
        pdf.close();

        System.out.println("Printing for excel document");
        DocumentFactory ob2 = new ExcelFactory();
        Document excel = ob2.createDocument();
        excel.write();
        excel.open();
        excel.close();
    }
}

