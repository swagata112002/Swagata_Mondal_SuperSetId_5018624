public class WordDocument extends Document {
    public void write(){
        System.out.println("Writing Word");
    }
    public void open() {
        System.out.println("Opening Word");
    }
    public void close() {
        System.out.println("Closing Word");
    }
}
