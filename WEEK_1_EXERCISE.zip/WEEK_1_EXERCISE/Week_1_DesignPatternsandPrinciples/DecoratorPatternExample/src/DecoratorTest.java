public class DecoratorTest {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        
        Notifier emailSMSNotifier = new SMSNotifierDecorator(emailNotifier);
        
        Notifier emailSlackNotifier = new SlackNotifierDecorator(emailSMSNotifier);
        
        System.out.println("EmailNotifier:");
        emailNotifier.send("Email...");
        
        System.out.println("SMSNotifier:");
        emailSMSNotifier.send("SMS...");
        
        System.out.println("SlackNotifier:");
        emailSlackNotifier.send("Slack...");
    }
}
