import java.util.*;

public class InventoryManagement{
    private HashMap<String,Product> inventory=new HashMap<>();

    public void add(Product product){
        inventory.put(product.getproductId(),product);
    }

    public void update(String productId, Product updateProduct){
        if (inventory.containsKey(productId)){
            inventory.put(productId,updateProduct);
        } 
        else{
            System.out.println("Product is not there");
        }
    }

    public void delete(String productId){
        inventory.remove(productId);
    }

    public void print(String productId){
        Product product=inventory.get(productId);
        if (product!=null){
            System.out.println(product);
        }
        else{
            System.out.println("Product not found");
        }
    }

    public static void main(String[] args){
        InventoryManagement ob=new InventoryManagement();
        Product ob1=new Product("1","Book",3,200);
        Product ob2=new Product("2","Doll",2,100);
        ob.add(ob1);
        ob.add(ob2);
        System.out.println("Before any operations the Products are :");
        ob.print("1");
        ob.print("2");
        System.out.println("After operations the Products are :");
        //add
        Product ob3=new Product("3","Clock",4,400);
        ob.add(ob3);
        //update
        Product updateProduct= new Product("1","Glass",1,15.5);
        ob.update("1", updateProduct);
        //delete
        ob.delete("2");

        ob.print("1");
        ob.print("2");
        ob.print("3");
    }
}

class Product {
    String productId;
    String productName;
    int quantity;
    double price;

    public Product(String productId,String productName,int quantity,double price) {
        this.productId=productId;
        this.productName=productName;
        this.quantity=quantity;
        this.price=price;
    }

    public String getproductId(){
        return productId;
    }

    public String getproduct(){
        return productName;
    }

    public int getQuantity(){
        return quantity;
    }

    public double getPrice(){
        return price;
    }

    public String toString() {
        return ("Product ID:" +productId+", Name: " +productName +", Quantity: " +quantity +", Price: " + price);
    }
}

// OUTPUT:
// Before any operations the Products are :
// Product ID:1, Name: Book, Quantity: 3, Price: 200.0
// Product ID:2, Name: Doll, Quantity: 2, Price: 100.0
// After operations the Products are :
// Product ID:1, Name: Glass, Quantity: 1, Price: 15.5
// Product not found
// Product ID:3, Name: Clock, Quantity: 4, Price: 400.0
