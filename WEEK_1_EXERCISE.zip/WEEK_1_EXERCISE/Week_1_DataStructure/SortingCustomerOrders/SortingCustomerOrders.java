import java.util.*;

public class SortingCustomerOrders{
    public static class Order{
        int orderId;
        String customerName;
        double totalPrice;
        public Order(int orderId,String customerName,double totalPrice){
            this.orderId=orderId;
            this.customerName=customerName;
            this.totalPrice=totalPrice;
        }
        public int getOrderId(){
            return orderId;
        }
        public String getCustomerName(){
            return customerName;
        }
        public double getTotalPrice(){
            return totalPrice;
        }
        public String toString(){
            return "Orderid:"+orderId+",customer='"+customerName+"',totalPrice="+totalPrice;
        }
    }
    public static void bubbleSort(Order[] order){
        for(int i=0;i<order.length-1;i++){
            for(int j=0;j<order.length-i-1;j++){
                if(order[j].getTotalPrice()>order[j+1].getTotalPrice()){
                    Order temp=order[j];
                    order[j]=order[j+1];
                    order[j+1]=temp;
                }
            }
        }
    }
    public static void quickSort(Order[] order,int low,int high){
        if(low<high){
            int p=partition(order,low,high);
            quickSort(order,low,p-1);
            quickSort(order,p+1,high);
        }
    }
    private static int partition(Order[] order,int low,int high){
        double pivot=order[high].getTotalPrice();
        int i=low-1;
        for(int j=low;j<high;j++){
            if(order[j].getTotalPrice()<=pivot){
                i++;
                Order temp=order[i];
                order[i]=order[j];
                order[j]=temp;
            }
        }
        Order temp=order[i+1];
        order[i+1]=order[high];
        order[high]=temp;
        return i+1;
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter '1' for Bubble Sort and '2' for Quick Sort");
        int ch=sc.nextInt();
        Order[] orders={
            new Order(1,"Maya",270),
            new Order(2,"Soma",375.60),
            new Order(3,"Swagata",19.24),
            new Order(4,"Arko",389.36),
            new Order(5,"Ram",150.25)
        };
        switch(ch){
            case 1:
                bubbleSort(orders);
                System.out.println("Sorted Orders (Bubble Sort):");
                printOrders(orders);
                break;
            case 2:
                quickSort(orders,0,orders.length-1);
                System.out.println("Sorted Orders (Quick Sort):");
                printOrders(orders);
                break;
            default:
                System.out.println("Wrong Input");
        }
        sc.close();
    }
    private static void printOrders(Order[] orders){
        for(Order order:orders){
            System.out.println(order);
        }
    }
}
// OUTPUT:
// Enter '1' for Bubble Sort and '2' for Quick Sort
// 1
// Sorted Orders (Bubble Sort):
// Orderid:3,customer='Swagata',totalPrice=19.24
// Orderid:5,customer='Ram',totalPrice=150.25
// Orderid:1,customer='Maya',totalPrice=270.0
// Orderid:2,customer='Soma',totalPrice=375.6
// Orderid:4,customer='Arko',totalPrice=389.36

// Enter '1' for Bubble Sort and '2' for Quick Sort
// 2
// Sorted Orders (Quick Sort):
// Orderid:3,customer='Swagata',totalPrice=19.24
// Orderid:5,customer='Ram',totalPrice=150.25
// Orderid:1,customer='Maya',totalPrice=270.0
// Orderid:2,customer='Soma',totalPrice=375.6
// Orderid:4,customer='Arko',totalPrice=389.36
