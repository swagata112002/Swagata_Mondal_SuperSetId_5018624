import java.util.*;

public class EmployeeManagementSystem{
    static class Employee{
        private int employeeId;
        private String name;
        private String position;
        private double salary;

        public Employee(int employeeId, String name, String position, double salary){
            this.employeeId=employeeId;
            this.name=name;
            this.position=position;
            this.salary=salary;
        }

        public int getEmployeeId(){
            return employeeId;
        }

        public String getName(){
            return name;
        }

        public String getPosition(){
            return position;
        }

        public double getSalary(){
            return salary;
        }

        public String toString(){
            return "Employee ID: "+employeeId+", Name: "+name+", Position: "+position+", Salary: "+salary;
        }
    }

    private Employee[] el;
    private int s;

    public EmployeeManagementSystem(int capacity){
        el=new Employee[capacity];
        s=0;
    }

    public void addEmployee(Employee employee){
        if(s>=el.length){
            System.out.println("Array is full");
            return;
        }
        el[s++]=employee;
    }

    public Employee searchEmployee(int employeeId){
        for(int i=0;i<s;i++){
            if(el[i].getEmployeeId()==employeeId){
                return el[i];
            }
        }
        return null;
    }

    public void traverseel(){
        for(int i=0;i<s;i++){
            System.out.println(el[i]);
        }
    }

    public void deleteEmployee(int employeeId){
        int ind=-1;
        for(int i=0;i<s;i++){
            if(el[i].getEmployeeId()==employeeId){
                ind=i;
                break;
            }
        }
        if(ind==-1){
            System.out.println("Employee with ID "+employeeId+" not found.");
            return;
        }
        for(int i=ind;i<s-1;i++){
            el[i]=el[i+1];
        }
        el[s-1]=null;
        s--;
    }

    public static void main(String[] args){
        EmployeeManagementSystem ob=new EmployeeManagementSystem(10);

        ob.addEmployee(new Employee(1,"Ram","Coder",50000));
        ob.addEmployee(new Employee(2,"Sam","Developer",60000));
        ob.addEmployee(new Employee(3,"yoyo","Designer",75000));

        System.out.println("Employee List:");
        ob.traverseel();

        Employee emp=ob.searchEmployee(2);
        System.out.println("Search Result:");
        if(emp!=null){
            System.out.println(emp);
        }else{
            System.out.println("Employee Name not found");
        }

        ob.deleteEmployee(2);
        System.out.println("Now List is:");
        ob.traverseel();
    }
}

// OUTPUT:
// Employee List:
// Employee ID: 1, Name: Ram, Position: Coder, Salary: 50000.0
// Employee ID: 2, Name: Sam, Position: Developer, Salary: 60000.0
// Employee ID: 3, Name: yoyo, Position: Designer, Salary: 75000.0
// Search Result:
// Employee ID: 2, Name: Sam, Position: Developer, Salary: 60000.0
// Now List is:
// Employee ID: 1, Name: Ram, Position: Coder, Salary: 50000.0
// Employee ID: 3, Name: yoyo, Position: Designer, Salary: 75000.0
