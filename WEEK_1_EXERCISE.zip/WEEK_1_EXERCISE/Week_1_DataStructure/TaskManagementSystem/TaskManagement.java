import java.util.*;
public class TaskManagement {
    public static class Task {
        int taskId;
        String taskName;
        String status;

        public Task(int taskId, String taskName, String status) {
            this.taskId = taskId;
            this.taskName = taskName;
            this.status = status;
        }
        public String toString() {
            return ("Task ID: " + taskId + ", Task Name: " + taskName + ", Status: " + status);
        }
    }

    private static class Node {
        Task task;
        Node next;

        public Node(Task task) {
            this.task = task;
            this.next = null;
        }
    }

    public static class Taskk {
        private Node head;

       //add
        public void add(Task task) {
            Node newNode = new Node(task);
            if (head == null) {
                head = newNode;
            } else {
                Node current = head;
                while (current.next != null) {
                    current = current.next;
                }
                current.next = newNode;
            }
        }

        //search
        public Task search(int taskId) {
            Node current = head;
            while (current != null) {
                if (current.task.taskId == taskId) {
                    return current.task;
                }
                current = current.next;
            }
            return null;
        }

        // traverse
        public void traverse() {
            Node current = head;
            while (current != null) {
                System.out.println(current.task);
                current = current.next;
            }
        }

        //delete
        public boolean delete(int taskId) {
            if (head == null) {
                return false;
            }
            if (head.task.taskId == taskId) {
                head = head.next;
                return true;
            }
            Node current = head;
            while (current.next != null) {
                if (current.next.task.taskId == taskId) {
                    current.next = current.next.next;
                    return true;
                }
                current = current.next;
            }
            return false;
        }
    }

    public static void main(String[] args) {
        Taskk tasks = new Taskk();
        Scanner sc=new Scanner(System.in);
        //adding
        tasks.add(new Task(1, "Task 1", "LOADING....."));
        tasks.add(new Task(2, "Task 2", "PROGRESSING...."));
        tasks.add(new Task(3, "Task 3", "COMPLETE"));

        //traverse
        System.out.println("Tasks are:");
        tasks.traverse();

        //search

        System.out.println("Enter a Id. to search:");
        int ser = sc.nextInt();
        Task task = tasks.search(ser);
        if (task != null) {
            System.out.println(task);
        } else {
            System.out.println("Task not found.");
        }

        //delete
        System.out.println("Enter a Id. to delete:");
        int del = sc.nextInt();
        boolean deleted = tasks.delete(del);
        if (deleted) {
            System.out.println("Deleted Id. is "+del);
        } else {
            System.out.println("Task not found.");
        }

        System.out.println("Tasks after deletion:");
        tasks.traverse();
    }
}
