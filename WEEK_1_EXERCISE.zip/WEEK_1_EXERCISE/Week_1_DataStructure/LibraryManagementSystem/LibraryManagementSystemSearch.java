import java.util.*;
public class LibraryManagementSystemSearch {
    public static class Book {
        int bookId;
        String title;
        String author;
        public Book(int bookId,String title,String author) {
            this.bookId=bookId;
            this.title=title;
            this.author=author;
        }
        public int getBookId() {
            return bookId;
        }
        public String getTitle() {
            return title;
        }
        public String getAuthor() {
            return author;
        }
        public String toString() {
            return ("Book ID:"+bookId+",Title:"+title+",Author:"+author);
        }
    }
    public static Book linearSearch(Book[] books,String key) {
        for(Book book:books) {
            if(book.getTitle().equalsIgnoreCase(key)) {
                return book;
            }
        }
        return null;
    }
    public static Book binarySearch(Book[] book,String key) {
        int l=0;
        int r=book.length-1;
        while(l<=r) {
            int mid=l+(r-l)/2;
            Book midBook=book[mid];
            int comparison=midBook.getTitle().compareToIgnoreCase(key);
            if(comparison==0) {
                return midBook;
            } 
            else if(comparison<0) {
                l=mid+1;
            } 
            else {
                r=mid-1;
            }
        }
        return null;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter '1' for linear search and '2' for binary search");
        int ch=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the title to search:");
        String key=sc.nextLine();
        switch(ch) {
            case 1:
                Book[] books={
                    new Book(1,"Pather Panchali","Bibhutibhushan Bandyopadhyay"),
                    new Book(3,"Gitanjali","Rabindranath Tagore"),
                    new Book(4,"Aparajito","Bibhutibhushan Bandyopadhyay"),
                    new Book(2,"Srikanta","Sarat Chandra Chattopadhyay"),
                    new Book(5,"Devdas","Sarat Chandra Chattopadhyay")
                };
                Book result=linearSearch(books,key);
                if(result!=null) {
                    System.out.println(result);
                } else {
                    System.out.println("Book not found.");
                }
                break;
            case 2:
                Book[] book={
                    new Book(1,"Aparajito","Bibhutibhushan Bandyopadhyay"),
                    new Book(5,"Devdas","Sarat Chandra Chattopadhyay"),
                    new Book(2,"Gitanjali","Rabindranath Tagore"),
                    new Book(1,"Pather Panchali","Bibhutibhushan Bandyopadhyay"),
                    new Book(4,"Srikanta","Sarat Chandra Chattopadhyay"),
                    
                };
                Book result1=binarySearch(book,key);
                if(result1!=null) {
                    System.out.println(result1);
                } 
                else {
                    System.out.println("Book not found.");
                }
                break;
            default:
                System.out.println("Wrong Input");
        }
        sc.close();
    }
}

// OUTPUT:
// Enter '1' for linear search and '2' for binary search
// 2
// Enter the title to search:
// Aparajito
// Book ID:1,Title:Aparajito,Author:Bibhutibhushan Bandyopadhyay

// Enter '1' for linear search and '2' for binary search
// 1
// Enter the title to search:
// Gitanjali
// Book ID:3,Title:Gitanjali,Author:Rabindranath Tagore