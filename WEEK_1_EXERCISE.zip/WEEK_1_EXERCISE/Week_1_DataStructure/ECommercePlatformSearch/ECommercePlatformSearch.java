import java.util.*;
public class ECommercePlatformSearch {
    public static class Product {
        int productId;
        String productName;
        String category;
    
        public Product(int productId,String productName,String category) {
            this.productId=productId;
            this.productName=productName;
            this.category=category;
        }
    
        public int getproductId(){
            return productId;
        }
    
        public String getProductName(){
            return productName;
        }
    
        public String getcategory(){
            return category;
        }
    
        public String toString(){
            return ("Product ID:" +productId+", Name: " +productName +", Category: " +category);
        }
    }
    
    //linear search
    public static Product linearSearch(Product[] element,int key){
        for(int i=0;i<element.length;i++) {
            if (element[i].getproductId()==key){
                return element[i];
            }
        }
        return null;
    }

    //binary search
    public static Product binarySearch(Product[] elements,int key){
        int l=0;
        int r=elements.length-1;
        while(l<=r) {
            int mid=l+(r-l)/2;
            Product midelement=elements[mid];
            if (midelement.getproductId()==key) {
                return midelement;
            } 
            else if(midelement.getproductId()<key){
                l=mid+1;
            } 
            else{
                r=mid-1;
            }
        }
        return null;
    }

    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter '1' for linear search and '2' for binary search");
        int ch=sc.nextInt();
        System.out.println("Enter the Id. to search:");
        int key = sc.nextInt();
        switch(ch){
            case 1:
                Product[] element={
                    new Product(1, "Fan", "Electronics"),
                    new Product(4, "Light", "Electronics"),
                    new Product(2, "Computer", "Electronics"),
                    new Product(3, "Bed", "Furniture"),
                    new Product(5, "Desk", "Furniture"),
                };
                Product result=linearSearch(element, key);
                if (result!=null){
                    System.out.println(result);
                } 
                else{
                    System.out.println("Product not found.");
                }
            break;
            case 2:
                Product[] elements={
                    new Product(1, "Fan", "Electronics"),
                    new Product(2, "Light", "Electronics"),
                    new Product(3, "Computer", "Electronics"),
                    new Product(4, "Bed", "Furniture"),
                    new Product(5, "Desk", "Furniture"),
                };
                Product result1=binarySearch(elements, key);
                if (result1!=null){
                    System.out.println(result1);
                } 
                else{
                    System.out.println("Product not found.");
                }
            break;
            default:
                System.out.println("Wrong Input");
        }

    }
}

// OUTPUT : 
// Enter '1' for linear search and '2' for binary search
// 1
// Enter the Id. to search:
// 3
// Product ID:3, Name: Bed, Category: Furniture
// Enter '1' for linear search and '2' for binary search
// 2
// Enter the Id. to search:
// 1
// Product ID:1, Name: Fan, Category: Electronics
