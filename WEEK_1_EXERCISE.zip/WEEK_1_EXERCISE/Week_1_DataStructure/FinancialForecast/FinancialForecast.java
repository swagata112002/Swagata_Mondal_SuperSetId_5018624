import java.util.*;
    public class FinancialForecast {

        public static double calculateFutureValue(double pastVal, double rate, int years) {
            if (years <= 0) {
                return pastVal;
            }
            return calculateFutureValue(pastVal *(1 + rate), rate, years - 1);
        }

        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter the initial value:");
            double pastVal = sc.nextDouble();
            System.out.print("Enter the rate:");
            double rate = sc.nextDouble();
            System.out.print("Enter the years:");
            int years = sc.nextInt();
            double futureValue = calculateFutureValue(pastVal, rate, years);
            System.out.printf("The future value after %d years is: %.2f%n", years, futureValue);
        }
    }


