--question1
CREATE OR REPLACE PROCEDURE TransferFundsSecurely(
    from_account_id NUMBER,
    to_account_id NUMBER,
    transfer_amount NUMBER
)
IS
    from_account_balance NUMBER;
    to_account_balance NUMBER;
    insufficient_balance EXCEPTION;
BEGIN
    -- Get balance of the from account
    SELECT Balance INTO from_account_balance FROM Accounts WHERE AccountID = from_account_id FOR UPDATE;
    
    -- Check if there are sufficient funds
    IF from_account_balance < transfer_amount THEN
        RAISE insufficient_balance;
    END IF;

    -- Perform the transfer
    UPDATE Accounts
    SET Balance = Balance - transfer_amount, LastModified = SYSDATE
    WHERE AccountID = from_account_id;

    UPDATE Accounts
    SET Balance = Balance + transfer_amount, LastModified = SYSDATE
    WHERE AccountID = to_account_id;

    COMMIT;
    
    DBMS_OUTPUT.PUT_LINE('Transfer successful.');
    
EXCEPTION
    WHEN insufficient_balance THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: Insufficient funds in the from account.');
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END TransferFundsSecurely;
/
--question2
CREATE OR REPLACE PROCEDURE TransferFundsSecurely(
    from_account_id NUMBER,
    to_account_id NUMBER,
    transfer_amount NUMBER
)
IS
    from_account_balance NUMBER;
    to_account_balance NUMBER;
    insufficient_balance EXCEPTION;
BEGIN
    -- Get balance of the from account
    SELECT Balance INTO from_account_balance FROM Accounts WHERE AccountID = from_account_id FOR UPDATE;
    
    -- Check if there are sufficient funds
    IF from_account_balance < transfer_amount THEN
        RAISE insufficient_balance;
    END IF;

    -- Perform the transfer
    UPDATE Accounts
    SET Balance = Balance - transfer_amount, LastModified = SYSDATE
    WHERE AccountID = from_account_id;

    UPDATE Accounts
    SET Balance = Balance + transfer_amount, LastModified = SYSDATE
    WHERE AccountID = to_account_id;

    COMMIT;
    
    DBMS_OUTPUT.PUT_LINE('Transfer successful.');
    
EXCEPTION
    WHEN insufficient_balance THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: Insufficient funds in the from account.');
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END TransferFundsSecurely;
/
BEGIN
    TransferFundsSecurely(1, 2, 500);
END;
/
--question3
CREATE OR REPLACE PROCEDURE AddCustomer(
    customer_id NUMBER,
    customer_name VARCHAR2,
    customer_dob DATE,
    initial_balance NUMBER
)
IS
    customer_already_exists EXCEPTION;
BEGIN
    -- Insert new customer
    INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
    VALUES (customer_id, customer_name, customer_dob, initial_balance, SYSDATE);

    COMMIT;
    
    DBMS_OUTPUT.PUT_LINE('Customer added successfully.');
    
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: Customer with ID ' || customer_id || ' already exists.');
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END AddCustomer;
/
