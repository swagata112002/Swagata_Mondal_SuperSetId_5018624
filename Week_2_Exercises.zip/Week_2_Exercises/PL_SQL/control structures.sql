--question1
DECLARE
    age_of_customer NUMBER;
    CURSOR cursor_customers IS
        SELECT c.CustomerID, c.DOB, l.InterestRate 
        FROM Customers c
        JOIN Loans l ON c.CustomerID = l.CustomerID;
BEGIN
    FOR customer_record IN cursor_customers LOOP
        age_of_customer := FLOOR(MONTHS_BETWEEN(SYSDATE, customer_record.DOB) / 12);
        
        IF age_of_customer > 60 THEN
            UPDATE Loans
            SET InterestRate = InterestRate - 1
            WHERE CustomerID = customer_record.CustomerID;
        END IF;
    END LOOP;
    COMMIT;
END;
/

--question2
ALTER TABLE Customers ADD VIP_Status VARCHAR2(3) DEFAULT 'NO';

BEGIN
    FOR customer_record IN (SELECT CustomerID, Balance FROM Customers) LOOP
        IF customer_record.Balance > 1000 THEN
            UPDATE Customers
            SET VIP_Status = 'YES'
            WHERE CustomerID = customer_record.CustomerID;
        END IF;
    END LOOP;
    COMMIT;
END;
/

SELECT * FROM Customers;
SELECT * FROM Accounts;


select * from Customers;
select * from Accounts;

--question3

DECLARE
    customer_full_name VARCHAR2(100);
    CURSOR cursor_loans IS
        SELECT l.LoanID, l.CustomerID, l.EndDate, c.Name 
        FROM Loans l
        JOIN Customers c ON l.CustomerID = c.CustomerID
        WHERE l.EndDate BETWEEN SYSDATE AND SYSDATE + 30;
BEGIN
    FOR loan_record IN cursor_loans LOOP
        customer_full_name := loan_record.Name;
        DBMS_OUTPUT.PUT_LINE('Reminder: Dear ' || customer_full_name || 
                             ', your loan with LoanID ' || loan_record.LoanID || 
                             ' is due on ' || TO_CHAR(loan_record.EndDate, 'YYYY-MM-DD') || 
                             '. Please ensure timely payment.');
    END LOOP;
END;
/

