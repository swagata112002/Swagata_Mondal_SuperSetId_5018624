--question1
CREATE OR REPLACE FUNCTION CalculateAge(date_of_birth DATE)
RETURN NUMBER
IS
    customer_age NUMBER;
BEGIN
    -- Calculate age in years
    customer_age := FLOOR(MONTHS_BETWEEN(SYSDATE, date_of_birth) / 12);
    RETURN customer_age;
END CalculateAge;
/
--question2
CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment(
    principal NUMBER,
    annual_rate NUMBER,
    term_years NUMBER
)
RETURN NUMBER
IS
    monthly_payment NUMBER;
    monthly_rate NUMBER;
    total_months NUMBER;
BEGIN
    -- Convert annual interest rate to monthly
    monthly_rate := annual_rate / 12 / 100;

    -- Calculate the total number of months
    total_months := term_years * 12;

    -- Calculate monthly installment using the formula
    monthly_payment := principal * monthly_rate /
        (1 - POWER((1 + monthly_rate), -total_months));

    RETURN monthly_payment;
END CalculateMonthlyInstallment;
/
--question3
CREATE OR REPLACE FUNCTION HasSufficientBalance(
    account_id NUMBER,
    required_amount NUMBER
)
RETURN BOOLEAN
IS
    current_balance NUMBER;
BEGIN
    -- Retrieve the balance of the specified account
    SELECT Balance INTO current_balance
    FROM Accounts
    WHERE AccountID = account_id;

    -- Check if the balance is sufficient
    IF current_balance >= required_amount THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN FALSE;
    WHEN OTHERS THEN
        RETURN FALSE;
END HasSufficientBalance;
/