package com.library.repository;

public class BookRepository {
	public void getMessage() {
		System.out.println("Response from Book Repository");
	}
}
