package com.library.service;

public class BookService {
	public void getMessage() {
		System.out.println("Response from Book Service");
	}

}
